#include <stdio.h>
int main() {
    int Matrix1 [ 5 ] [ 5 ] , Matrix2 [ 5 ] [ 5 ] , Matrix3 [ 5 ] [ 5 ] , Matrix4[5][5] ;
    int rows1 , cols1 , rows2 , cols2 , rows3 , cols3 , rows4 , cols4 ;
    int i , j , k ;
    printf( " Enter Matrix1 : \n" ) ;
    printf( " Enter number rows and columns : \n " ) ;
    scanf( " %d %d \n " , &rows1 , &cols1 ) ;
    for( i = 0 ; i < rows1 ; i++ ) {
        for( j = 0 ; j < cols1 ; j++ ) {
            printf("Enter [%d %d] value : \n ", i , j ) ;
            scanf( " %d \n ", Matrix1 [ i ] [ j ] ) ;
        }//end for
    }//end for
    
    printf( " Enter Matrix2 : \n " ) ; 
    printf( " Enter number rows and columns : \n ") ;
    scanf( " %d %d \n " , &rows2 , &cols2 ) ;
    for( i = 0 ; i < rows2 ; i++ ) {
        for( j = 0 ; j < cols2 ; j++ ) {
            printf( " Enter [%d %d] value : \n ", &i , &j ) ;
            scanf( "%d \n " , &Matrix2 [ i ] [ j ] ) ;
        }//end for
    }//end for
    
    printf( " Matrix1 : \n " ) ;
    for( i = 0 ; i < rows1 ; i++ ) {
        for( j = 0 ; j<cols1; j++ ) {
            printf( "%d \n " , &Matrix1 [ i ] [ j ] ) ;
        }//end for
        printf("\n") ;
    }//end for
    
    printf( " Matrix2 : \n " ) ;
    for( i = 0 ; i < rows2 ; i++ ) {
        for( j = 0 ; j < cols2 ; j++ ) {
            printf("%d \n ", Matrix2 [ i ] [ j ] ) ;
        }//end for
        printf( " \n " ) ;
    }//end for
   
    rows3 = cols1 ;
    cols3 = rows1 ;
    for( i = 0 ; i < rows3 ; i++ ) {
        for( j = 0 ; j < cols3 ; j++ ) {
            Matrix3 [ i ] [ j ] = Matrix1 [ j ] [ i ] ;
        }//end for
    }//end for
    
    printf( " Transpose of Matrix1 is : \n " ) ;
    for( i = 0 ; i < rows3 ; i++ ) {
        for( j = 0 ; j < cols3 ; j++ ) {
            printf( " %d ", Matrix3 [ i ] [ j ] ) ; 
        }//end for
        printf( " \n " ) ;
    }//end for
    
    if(cols1!=rows2) {
        printf(" Matrix1 and Matrix2 connot multiply : \n " ) ;
    }else {   
        rows4 = rows1 ;
        cols4 = cols2 ;
    }//end else
    
    for(i=0;i<rows4;i++) {
        for(j=0;j<cols4;j++) {
            Matrix4 [ i ] [ j ] = 0 ;
            for( k = 0 ; k < cols1 ; k++ ) {
            Matrix4 [ i ] [ j ] += Matrix1 [ i ] [ k ] * Matrix2 [ k ] [ j ] ;
            }//end for
        }//end for
    }//end for
    
    printf( " Matrix1 x Matrix2 is : \n " ) ;
    for( i = 0 ; i < rows4 ; i++ ) {
        for( j = 0 ; j < cols4 ; j++ ) {
            printf("%d \n ", &Matrix4 [ i ] [ j ] ) ;
        }//end for   
        printf( " \n " ) ;
    }//end for
    return 0 ;
}//end main