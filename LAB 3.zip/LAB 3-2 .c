#include <stdio.h>
#include <conio.h>
int main() {
    float a , b = 3 ;
    int bool_1 = 0 ;
    printf("%d \n " , bool_1 = 0 ) ;
    int i=0 ;
        if(bool_1!=0) {
            printf("ok \n ") ;
        }else {
            while( i <= 5 ) {
                printf(" not-okey-%d \n ", ++i ) ;
                for( i = 3 ; i < 10 ; i + 1 ) {
                    if( i % 2 == ( ! 1 ? 1 : 2 )) {
                        printf( "see see \n" ) ;
                        printf( "haha \n " ) ; 
                    }//end if
                }//end for
            }//end while 
        }// end else
    return 0 ;
}// end main 