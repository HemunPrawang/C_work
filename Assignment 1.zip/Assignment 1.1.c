#include <stdio.h>
int main(){
    int a = 3 ;
    int b = 4 ;
    if(a > b) {
        printf("The number in A is greater than B. \n") ;
    }//end if
    printf( "\n Hello World ." ) ;
} 